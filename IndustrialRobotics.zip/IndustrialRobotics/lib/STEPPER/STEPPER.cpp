#include "STEPPER.h"
#include <Arduino.h>

Stepper::Stepper()
{
}

Stepper::~Stepper()
{
}

void Stepper::setup(int dir, int step)
{
    _dir = dir;
    _step = step;
}

void Stepper::turn(float delay_cpp, float distance)
{

    for (int x = 0; x < NUM_STEPS * 1; x++)
    {
        digitalWrite(_step, HIGH);
        // delayMicroseconds(stepDelay);
        delay(DELAY_STEPS + delay_cpp);
        digitalWrite(_step, LOW);
        // delayMicroseconds(stepDelay);
        delay(DELAY_STEPS + delay_cpp);
    }
}

void Stepper::stop()
{

    for (int x = 0; x < NUM_STEPS * 1; x++)
    {
        digitalWrite(_step, LOW);
        delay(DELAY_STEPS);
    }
}

bool Stepper::getDirection()
{
    if (digitalRead(_dir) == HIGH)
    {
        _fdir = true;
    }
    else
    {
        _fdir = false;
    }
    return _fdir;
}
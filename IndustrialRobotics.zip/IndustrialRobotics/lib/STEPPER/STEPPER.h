#ifndef _STEPPER
#define _STEPPER

#define NUM_STEPS 100
#define DELAY_STEPS 10

#include "PID.h"

class Stepper
{
public:
    PIDController PID;
    Stepper();
    ~Stepper();
    void setup(int dir, int step);
    void turn(float delay_pid, float distance);
    void stop();
    bool getDirection();

private: 
    int _dir;
    int _step;
    bool _fdir;
    float _distance;
};



#endif
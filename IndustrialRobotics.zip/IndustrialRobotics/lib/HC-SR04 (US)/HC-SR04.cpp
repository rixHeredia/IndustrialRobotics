#include "HC-SR04.h"
#include <Arduino.h>

USsensor::USsensor()
{
}

USsensor::~USsensor()
{
}

void USsensor::setup(int trigger, int echo, volatile unsigned long pulse_begin, volatile unsigned long pulse_end, volatile bool new_pulse, float distance, unsigned long pulse_duration)
{
    _trigger = trigger;
    _echo = echo;
    _pulse_begin = pulse_begin;
    _pulse_end = pulse_end;
    _new_pulse = new_pulse;
    _distance = distance;
    _pulse_duration = pulse_duration;
    pinMode(_trigger, OUTPUT);
    pinMode(_echo, INPUT);
}

void USsensor::setFlag()
{
    _new_pulse = true;   
}

void USsensor::resetFlag()
{
    _new_pulse = false;   
}

bool USsensor::getFlag()
{
    return _new_pulse;   
}

void USsensor::setPulse()
{
    digitalWrite(_trigger, LOW);
    delayMicroseconds(CLEAN_TIME);
    digitalWrite(_trigger, HIGH);
    delayMicroseconds(PULSE_TIME);
    digitalWrite(_trigger, LOW);
}

void USsensor::echoInterrupt()
{
    if (digitalRead(_echo) == HIGH)
    {
        // start measuring
        _pulse_begin = micros();
    }
    else
    {
        // stop measuring
        _pulse_end = micros();
        setFlag();
    }
}

long USsensor::getTime()
{
    resetFlag();
    _pulse_duration = _pulse_end - _pulse_begin;
    return _pulse_duration;

}

float USsensor::getDistance(unsigned long pulse_duration)
{
    _distance = pulse_duration*PROP_CONST;
    return _distance;
}

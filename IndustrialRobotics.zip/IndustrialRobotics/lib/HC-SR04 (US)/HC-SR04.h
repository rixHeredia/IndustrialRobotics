#ifndef _HC-SR04
#define _HC-SR04

#define UPPER_LIMIT 400
#define LOWER_LIMIT 0.3F
#define PROP_CONST 0.01715 
#define CLEAN_TIME 2
#define PULSE_TIME 10

class USsensor
{
public:
    USsensor();
    ~USsensor();
    void setup(int trigger, int echo, volatile unsigned long pulse_begin,volatile unsigned long pulse_end, volatile bool new_pulse, float distance, unsigned long pulse_duration); //ok
    void setPulse(); //ok
    void echoInterrupt(); //ok
    long getTime(); //ok
    float getDistance(unsigned long pulse_duration);
    void setFlag (); //ok
    bool getFlag (); //ok
    void resetFlag(); //ok

private:
    int _trigger;
    int _echo;
    volatile unsigned long _pulse_begin;
    volatile unsigned long _pulse_end;
    volatile bool _new_pulse;
    float _distance;
    unsigned long _pulse_duration;

};


#endif
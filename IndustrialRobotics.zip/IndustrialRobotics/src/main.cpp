#include <Arduino.h>
#include "HC-SR04.h"
#include "STEPPER.h"
#include "PID.h"

// Definitions
#define ECHO_PIN 3
#define TRIGGER_PIN 10

#define DIR_PIN 5
#define STEP_PIN 4
#define DIR_PIN2 9
#define STEP_PIN2 8

#define SAMPLING 100
#define SAMPLING_PID 10

// Objects
USsensor Ultrasonic;
Stepper Apasos;
Stepper Apasos2;
PIDController PIDA;
PIDController PIDB;

// Variables
volatile unsigned long pulse_begining = micros();
volatile unsigned long pulse_ending = micros();
volatile bool pulse_available = false;
float distance;
unsigned long pulse_width = 0;

String coordx = "";
bool out_while = true;

float reference = 10;
float position;
float speed;
long prevTime;
long pid_time;
float outPID, outPID2;
float time_PID = SAMPLING_PID / 1000;
float kp = 1, ki = 0.5, kd = 0.25;
int resolution_sensor = 11;

void echoPinInterrupt()
{
  // Interruption
  Ultrasonic.echoInterrupt();
}

void setup()
{
  // put your setup code here, to run once:
  Serial.begin(9600);
  Ultrasonic.setup(TRIGGER_PIN, ECHO_PIN, pulse_begining, pulse_ending, pulse_available, distance, pulse_width);
  Apasos.setup(DIR_PIN, STEP_PIN);
  Apasos2.setup(DIR_PIN2, STEP_PIN2);
  PIDA.setup(kp, ki, kd, resolution_sensor);
  PIDB.setup(kp, ki, kd, resolution_sensor);
  attachInterrupt(digitalPinToInterrupt(ECHO_PIN), echoPinInterrupt, CHANGE);
}

void loop()
{
  // Generate a pulse
  Ultrasonic.setPulse();

  // Distance and time calculation
  if (Ultrasonic.getFlag())
  {
    // Time
    pulse_width = Ultrasonic.getTime();

    // Distance
    distance = Ultrasonic.getDistance(pulse_width);

    if (distance >= 400 || distance <= 0.5)
    {
      Serial.println("OOR");
    }
    else
    {
      Serial.println(distance);
    }
  }

  // Control part
  if (millis() - pid_time > SAMPLING_PID)
  {
    pid_time = millis();
    position = distance;
    outPID = PIDA.setControl(position, reference);
    outPID2 = PIDA.setControl(position, reference);
  }

  // Put upper and lower limits
  if (PIDA.TorF(3.0f, outPID))
  {
    outPID = 100;
  }
  else if (PIDA.TorF(outPID, 10.0f))
  {
    outPID = 1;
  }
  else if (PIDA.TorF(outPID, 3.0f) && PIDA.TorF(10.0f, outPID))
  {
    outPID = outPID;
  }

  // Motor 2
  if (PIDB.TorF(3.0f, outPID2))
  {
    outPID2 = 100;
  }
  else if (PIDB.TorF(outPID2, 10.0f))
  {
    outPID2 = 1;
  }
  else if (PIDB.TorF(outPID2, 3.0f) && PIDB.TorF(10.0f, outPID2))
  {
    outPID2 = outPID2;
  }


  // Stopping the motors
  if (distance < reference)
  {
    Apasos.stop();
    Apasos2.stop();
  }

  // Start moving the motors
  Apasos.turn(outPID, distance);   // Y axis
  Apasos2.turn(outPID2, distance); // Y axis

}